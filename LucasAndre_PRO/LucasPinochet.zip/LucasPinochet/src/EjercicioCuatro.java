public class EjercicioCuatro
{
    public static void main(String[] args)
    {
        Object[][] datos = new Object[10][4];

    }
}
